/**
 * Created by Danny on 2015/9/20 10:28.
 */

var People = require("./test/People.js");
var xiaoming = new People("小明","男","12");
xiaoming.sayHello();