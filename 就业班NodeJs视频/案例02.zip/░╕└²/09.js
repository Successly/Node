/**
 * Created by Danny on 2015/9/20 11:53.
 */
var bar = require("./test/foo.js");