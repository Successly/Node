/**
 * Created by Danny on 2015/9/20 10:28.
 */
var bar = require("bar");  //在引用一个文件夹

console.log(bar.msg);
