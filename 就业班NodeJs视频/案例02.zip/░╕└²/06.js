/**
 * Created by Danny on 2015/9/20 10:28.
 */
var foo = require("foo.js");  //没有写./

console.log(foo.msg);